Sorttable written by Stuart Langridge.
Please find infos about the library here:
https://www.kryogenix.org/code/browser/sorttable/
