# coding-utf8
from math import sqrt
from math import tanh

import sys
from time import time

# import python from parent directory like pointed out here:
# https://stackoverflow.com/questions/714063/importing-modules-from-parent-folder
import os
import sys
import inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)
from PyNite import FEModel3D

import pickle

# get arguments
path_import = sys.argv[1]
scipy_available = sys.argv[2]

def imported_truss():
    file = open(path_import, 'rb')
    truss = pickle.load(file)
    file.close()

    return truss

def run_fea(scipy_available, truss):
    if scipy_available == "True":
        truss.analyze(check_statics=False, sparse=True)
    if scipy_available == "False":
        truss.analyze(check_statics=False, sparse=False)

    return truss

def export_truss(fea):
    # export back to blender
    file = open(path_import, 'wb')
    pickle.dump(fea, file, protocol=-1)
    file.close()

if __name__ == "__main__":
    truss = imported_truss()
    fea = run_fea(scipy_available, truss)
    export_truss(fea)
    sys.exit()
