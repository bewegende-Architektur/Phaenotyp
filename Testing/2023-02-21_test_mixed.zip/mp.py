# coding-utf8
from multiprocessing import Manager, Value, cpu_count, Pool
from math import sqrt
from math import tanh

import sys
from time import time

# import python from parent directory like pointed out here:
# https://stackoverflow.com/questions/714063/importing-modules-from-parent-folder
import os
import sys
import inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)
from PyNite import FEModel3D

import pickle

# get arguments
directory_blend = sys.argv[1]
path_import = directory_blend + "/Phaenotyp-export_mp.p"
scipy_available = sys.argv[2]

# start timer
start_time = time()

def import_trusses():
    # get trusses stored as dict with frame as key
    file = open(path_import, 'rb')
    imported_trusses = pickle.load(file)
    file.close()

    return imported_trusses

def export_trusses(frame, truss):
    # export back to blender
    path_export = directory_blend + "/Phaenotyp-sp/" + str(frame) + ".p"
    file = open(path_export, 'wb')
    pickle.dump(truss, file)
    file.close()

def run_fea(scipy_available, truss, frame):
    if scipy_available == "True":
        truss.analyze(check_statics=False, sparse=True)
    if scipy_available == "False":
        truss.analyze(check_statics=False, sparse=False)

    export_trusses(frame, truss)

    print(str(frame))
    sys.stdout.flush()

def mp_pool():
    global scipy_available

    cores = cpu_count()

    pool = Pool(processes=cores)
    for frame, truss in imported_trusses.items():
        pool.apply_async(run_fea, args=(scipy_available, truss, frame,))

    pool.close()
    pool.join()

if __name__ == "__main__":
    imported_trusses = import_trusses()
    mp_pool()
    sys.exit()
