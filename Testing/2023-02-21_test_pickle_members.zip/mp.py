# coding-utf8
from multiprocessing import Manager, Value, cpu_count, Pool
from numpy import array, empty, append, poly1d, polyfit
from math import sqrt
from math import tanh

import sys
from time import time

# import python from parent directory like pointed out here:
# https://stackoverflow.com/questions/714063/importing-modules-from-parent-folder
import os
import sys
import inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)
from PyNite import FEModel3D

import pickle
import gc
gc.disable()

class basics:
    @staticmethod
    def return_max_diff_to_zero(list):
        list_copy = list.copy()
        list_copy.sort()

        smallest_minus = list_copy[0]
        biggest_plus = list_copy[len(list_copy)-1]

        if abs(smallest_minus) > abs(biggest_plus):
            return smallest_minus
        else:
            return biggest_plus

class material:
    kn_lamda = [10,20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200,210,220,230,240,250]

    kn235 = [16.5,15.8,15.3,14.8,14.2,13.5,12.7,11.8,10.7,9.5,8.2,6.9,5.9,5.1,4.4,3.9,3.4,3.1,2.7,2.5,2.2,2,1.9,1.7,1.6]
    kn275 = [20.5,19.4,18.8,18.0,17.1,16.0,14.8,13.3,11.7,9.9,8.2,6.9,5.9,5.1,4.4,3.9,3.4,3.1,2.7,2.5,2.2,2,1.9,1.7,1.6]
    kn355 = [24.5,23.2,22.3,21.2,20.0,18.5,16.7,14.7,12.2,9.9,8.2,6.9,5.9,5.1,4.4,3.9,3.4,3.1,2.7,2.5,2.2,2,1.9,1.7,1.6]
    knalu = [10.0,9.6,9.3,9,8.6,8.2,7.7,7.2,6.5,5.8,5.0,4.2,3.6,3.1,2.7,2.4,2.1,1.9,1.6,1.5,1.3,1.2,1.2,1.0,1.0]
    knholz = [1.60,1.33,1.28,1.20,1.11,1,0.86,0.71,0.56,0.46,0.38,0.32,0.27,0.23,0.2,0.18,0.16,0.14,0.127,0.114,0.114,0.114,0.114,0.114,0.114]
    kncustom = [16.5,15.8,15.3,14.8,14.2,13.5,12.7,11.8,10.7,9.5,8.2,6.9,5.9,5.1,4.4,3.9,3.4,3.1,2.7,2.5,2.2,2,1.9,1.7,1.6]

    library = [
        # name, name in dropdown, E, G, d, acceptable_sigma, acceptable_shear, acceptable_torsion, acceptable_sigmav, knick_model
        # diese gelten nach ÖNORM B 4600 für den Erhöhungsfall und entsprechen 100 % beim Knicken (lamda<20)
        ["steel_S235", "steel S235", 21000, 8100, 7.85, 16.5, 9.5, 10.5, 23.5, kn235],
        ["steel_S275", "steel S275", 21000, 8100, 7.85, 20.5, 11, 12.5, 27.5, kn275],
        ["steel_S355", "steel S355", 21000, 8100, 7.85, 24.5, 13, 15, 35.5, kn355],
        ["alu_EN_AC_Al_CU4Ti", "alu EN-AC Al Cu4Ti", 8000, 3000, 2.70, 10, 7, 10.5, 22.0, knalu],
        ["wood", "wood", 1000, 55, 0.35, 1.6, 0.1, 0.1, 2, knholz],
        ["custom", "Custom", 21000, 8100, 7.85, 16.0, 9.5, 10.5, 23.5, kncustom]
        ]

def print_data(text):
    print("Phaenotyp |", text)

# get arguments
directory_blend = sys.argv[1]
path_import = directory_blend + "/Phaenotyp-mp/Phaenotyp-export_mp.p"
scipy_available = sys.argv[2]

# start timer
start_time = time()

def import_data():
    # get trusses stored as dict with frame as key
    file = open(path_import, 'rb')
    imported_data = pickle.load(file)
    trusses, members = imported_data[0], imported_data[1]
    file.close()

    return trusses, members

def export_members(frame, members):
    # export back to blender
    path_export = directory_blend + "/Phaenotyp-mp/" + str(frame) + ".p"
    file = open(path_export, 'wb')
    pickle.dump(members, file)
    file.close()

def run_fea(scipy_available, truss, members, frame):
    if scipy_available == "True":
        truss.analyze(check_statics=False, sparse=True)
    if scipy_available == "False":
        truss.analyze(check_statics=False, sparse=False)

    for name, truss_member in truss.Members.items():
        frame = str(frame)
        id = name[7:]
        member = members[id]
        L = truss_member.L() # Member length
        T = truss_member.T() # Member local transformation matrix

        axial = []
        moment_y = []
        moment_z = []
        shear_y = []
        shear_z = []
        torque = []

        for i in range(11): # get the forces at 11 positions and
            x = L/10*i

            axial_pos = truss_member.axial(x) * (-1) # Druckkraft minus
            axial.append(axial_pos)

            moment_y_pos = truss_member.moment("My", x)
            moment_y.append(moment_y_pos)

            moment_z_pos = truss_member.moment("Mz", x)
            moment_z.append(moment_z_pos)

            shear_y_pos = truss_member.shear("Fy", x)
            shear_y.append(shear_y_pos)

            shear_z_pos = truss_member.shear("Fz", x)
            shear_z.append(shear_z_pos)

            torque_pos = truss_member.torque(x)
            torque.append(torque_pos)

        member["axial"][frame] = axial
        member["moment_y"][frame] = moment_y
        member["moment_z"][frame] = moment_z
        member["shear_y"][frame] = shear_y
        member["shear_z"][frame] = shear_z
        member["torque"][frame] = torque

        # shorten and accessing once
        A = member["A"][frame]
        J = member["J"][frame]
        Do = member["Do"][frame]

        # buckling
        member["ir"][frame] = sqrt(J/A) # für runde Querschnitte in  cm

        # modulus from the moments of area
        #(Wy and Wz are the same within a pipe)
        member["Wy"][frame] = member["Iy"][frame]/(Do/2)

        # polar modulus of torsion
        member["WJ"][frame] = J/(Do/2)

        # calculation of the longitudinal stresses
        long_stress = []
        for i in range(11): # get the stresses at 11 positions and
            moment_h = sqrt(moment_y[i]**2+moment_z[i]**2)
            if axial[i] > 0:
                s = axial[i]/A + moment_h/member["Wy"][frame]
            else:
                s = axial[i]/A - moment_h/member["Wy"][frame]
            long_stress.append(s)

        # get max stress of the beam
        # (can be positive or negative)
        member["long_stress"][frame] = long_stress
        member["max_long_stress"][frame] = basics.return_max_diff_to_zero(long_stress) #  -> is working as fitness

        # calculation of the shear stresses from shear force
        # (always positive)
        tau_shear = []
        shear_h = []
        for i in range(11): # get the stresses at 11 positions and
            # shear_h
            s_h = sqrt(shear_y[i]**2+shear_z[i]**2)
            shear_h.append(s_h)

            tau = 1.333 * s_h/A # for pipes
            tau_shear.append(tau)

        member["shear_h"][frame] = shear_h

        # get max shear stress of shear force of the beam
        # shear stress is mostly small compared to longitudinal
        # in common architectural usage and only importand with short beam lenght
        member["tau_shear"][frame] = tau_shear
        member["max_tau_shear"][frame] = max(tau_shear)

        # Calculation of the torsion stresses
        # (always positiv)
        tau_torsion = []
        for i in range(11): # get the stresses at 11 positions and
            tau = abs(torque[i]/member["WJ"][frame])
            tau_torsion.append(tau)

        # get max torsion stress of the beam
        member["tau_torsion"][frame] = tau_torsion
        member["max_tau_torsion"][frame] = max(tau_torsion)

        # torsion stress is mostly small compared to longitudinal
        # in common architectural usage

        # calculation of the shear stresses form shear force and torsion
        # (always positiv)
        sum_tau = []
        for i in range(11): # get the stresses at 11 positions and
            tau = tau_shear[0] + tau_torsion[0]
            sum_tau.append(tau)

        member["sum_tau"][frame] = sum_tau
        member["max_sum_tau"][frame] = max(sum_tau)

        # combine shear and torque
        sigmav = []
        for i in range(11): # get the stresses at 11 positions and
            sv = sqrt(long_stress[0]**2 + 3*sum_tau[0]**2)
            sigmav.append(sv)

        member["sigmav"][frame] = sigmav
        member["max_sigmav"][frame] = max(sigmav)
        # check out: http://www.bs-wiki.de/mediawiki/index.php?title=Festigkeitsberechnung

        member["sigma"][frame] = member["long_stress"][frame]
        member["max_sigma"][frame] = member["max_long_stress"][frame]

        # overstress
        member["overstress"][frame] = False

        # check overstress and add 1.05 savety factor
        safety_factor = 1.05
        if abs(member["max_tau_shear"][frame]) > safety_factor*member["acceptable_shear"]:
            member["overstress"][frame] = True

        if abs(member["max_tau_torsion"][frame]) > safety_factor*member["acceptable_torsion"]:
            member["overstress"][frame] = True

        if abs(member["max_sigmav"][frame]) > safety_factor*member["acceptable_sigmav"]:
            member["overstress"][frame] = True

        # buckling
        if member["axial"][frame][0] < 0: # nur für Druckstäbe, axial kann nicht flippen?
            member["lamda"][frame] = L*0.5/member["ir"][frame] # für eingespannte Stäbe ist die Knicklänge 0.5 der Stablänge L, Stablänge muss in cm sein !
            if member["lamda"][frame] > 20: # für lamda < 20 (kurze Träger) gelten die default-Werte)
                kn = member["knick_model"]
                function_to_run = poly1d(polyfit(material.kn_lamda, kn, 6))
                member["acceptable_sigma_buckling"][frame] = function_to_run(member["lamda"][frame])
                if member["lamda"][frame] > 250: # Schlankheit zu schlank
                    member["overstress"][frame] = True
                if safety_factor*abs(member["acceptable_sigma_buckling"][frame]) > abs(member["max_sigma"][frame]): # Sigma
                    member["overstress"][frame] = True

            else:
                member["acceptable_sigma_buckling"][frame] = member["acceptable_sigma"]

        # without buckling
        else:
            member["acceptable_sigma_buckling"][frame] = member["acceptable_sigma"]
            member["lamda"][frame] = None # to avoid missing KeyError


        if abs(member["max_sigma"][frame]) > safety_factor*member["acceptable_sigma"]:
            member["overstress"][frame] = True

        # lever_arm
        lever_arm = []
        moment_h = []
        for i in range(11):
            # moment_h
            m_h = sqrt(moment_y[i]**2+moment_z[i]**2)
            moment_h.append(m_h)

            # to avoid division by zero
            if member["axial"][frame][i] < 0.1:
                lv = m_h / 0.1
            else:
                lv = m_h / member["axial"][frame][i]

            lv = abs(lv) # absolute highest value within member
            lever_arm.append(lv)

        member["moment_h"][frame] = moment_h
        member["lever_arm"][frame] = lever_arm
        member["max_lever_arm"][frame] = max(lever_arm)

        # Ausnutzungsgrad
        member["utilization"][frame] = abs(member["max_long_stress"][frame] / member["acceptable_sigma_buckling"][frame])

        # Einführung in die Technische Mechanik - Festigkeitslehre, H.Balke, Springer 2010
        normalkraft_energie=[]
        moment_energie=[]
        strain_energy = []

        for i in range(10): # get the energie at 10 positions for 10 section
            # Berechnung der strain_energy für Normalkraft
            ne = (axial[i]**2)*(L/10)/(2*member["E"]*A)
            normalkraft_energie.append(ne)

            # Berechnung der strain_energy für Moment
            moment_hq = moment_y[i]**2+moment_z[i]**2
            me = (moment_hq * L/10) / (member["E"] * member["Wy"][frame] * Do)
            moment_energie.append(me)

            # Summe von Normalkraft und Moment-Verzerrunsenergie
            value = ne + me
            strain_energy.append(value)

        member["strain_energy"][frame] = strain_energy
        member["normal_energy"][frame] = normalkraft_energie
        member["moment_energy"][frame] = moment_energie

        # deflection
        deflection = []

        # --> taken from pyNite VisDeformedMember: https://github.com/JWock82/PyNite
        scale_factor = 10.0

        cos_x = array([T[0,0:3]]) # Direction cosines of local x-axis
        cos_y = array([T[1,0:3]]) # Direction cosines of local y-axis
        cos_z = array([T[2,0:3]]) # Direction cosines of local z-axis

        DY_plot = empty((0, 3))
        DZ_plot = empty((0, 3))

        for i in range(11):
            # Calculate the local y-direction displacement
            dy_tot = truss_member.deflection('dy', L/10*i)

            # Calculate the scaled displacement in global coordinates
            DY_plot = append(DY_plot, dy_tot*cos_y*scale_factor, axis=0)

            # Calculate the local z-direction displacement
            dz_tot = truss_member.deflection('dz', L/10*i)

            # Calculate the scaled displacement in global coordinates
            DZ_plot = append(DZ_plot, dz_tot*cos_z*scale_factor, axis=0)

        # Calculate the local x-axis displacements at 20 points along the member's length
        DX_plot = empty((0, 3))

        Xi = truss_member.i_node.X
        Yi = truss_member.i_node.Y
        Zi = truss_member.i_node.Z

        for i in range(11):
            # Displacements in local coordinates
            dx_tot = [[Xi, Yi, Zi]] + (L/10*i + truss_member.deflection('dx', L/10*i)*scale_factor)*cos_x

            # Magnified displacements in global coordinates
            DX_plot = append(DX_plot, dx_tot, axis=0)

        # Sum the component displacements to obtain overall displacement
        D_plot = DY_plot + DZ_plot + DX_plot

        # <-- taken from pyNite VisDeformedMember: https://github.com/JWock82/PyNite

        # add to results
        for i in range(11):
            x = D_plot[i, 0] * 0.01
            y = D_plot[i, 1] * 0.01
            z = D_plot[i, 2] * 0.01

            deflection.append([x,y,z])

        member["deflection"][frame] = deflection

    export_members(str(frame), members)

    print(str(frame))
    sys.stdout.flush()

def mp_pool(trusses, members):
    global scipy_available

    cores = cpu_count()

    pool = Pool(processes=cores)
    for frame, truss in trusses.items():
        pool.apply_async(run_fea, args=(scipy_available, truss, members, frame,))

    pool.close()
    pool.join()

if __name__ == "__main__":
    trusses, members = import_data()
    mp_pool(trusses, members)
    sys.exit()
