import bpy
import bmesh
from PyNite import FEModel3D
from numpy import array, empty, append, poly1d, polyfit
from phaenotyp import basics, material, progress
from math import sqrt
from math import tanh

from subprocess import Popen, PIPE
from threading import Thread
import sys
import os

# load pickle and disable garbagecollection
import pickle
import gc
gc.disable()

def print_data(text):
    print("Phaenotyp |", text)

def check_scipy():
    scene = bpy.context.scene
    data = scene["<Phaenotyp>"]

    try:
        import scipy
        data["scipy_available"] = True

    except:
        data["scipy_available"] = False

def prepare_fea():
    scene = bpy.context.scene
    phaenotyp = scene.phaenotyp
    data = scene["<Phaenotyp>"]
    frame = bpy.context.scene.frame_current
    truss = FEModel3D()

    # apply chromosome if available
    try:
        for id, key in enumerate(data.shape_keys):
            v = data.chromosome[str(frame)][id]
            key.value = v
    except:
        pass

    # get absolute position of vertex (when using shape-keys, animation et cetera)
    dg = bpy.context.evaluated_depsgraph_get()
    obj = data["structure"].evaluated_get(dg)

    mesh = obj.to_mesh(preserve_all_data_layers=True, depsgraph=dg)
    vertices = mesh.vertices
    edges = mesh.edges
    faces = mesh.polygons

    # like suggested here by Gorgious and CodeManX:
    # https://blender.stackexchange.com/questions/6155/how-to-convert-coordinates-from-vertex-to-world-space
    mat = obj.matrix_world

    # to be collected:
    data["frames"][str(frame)] = {}
    frame_volume = 0
    frame_area = 0
    frame_length = 0
    frame_kg = 0

    # get volume of this frame
    bm = bmesh.new()
    bm.from_mesh(mesh)
    frame_volume = bm.calc_volume()

    # get area of the frame
    # overall sum of faces
    # user can delete faces to influence this as fitness in ga
    for face in faces:
        frame_area += face.area

    # add nodes from vertices
    for vertex in vertices:
        vertex_id = vertex.index
        name = "node_" + str(vertex_id)

        # like suggested here by Gorgious and CodeManX:
        # https://blender.stackexchange.com/questions/6155/how-to-convert-coordinates-from-vertex-to-world-space
        v = mat @ vertex.co

        x = v[0] * 100 # convert to cm for calculation
        y = v[1] * 100 # convert to cm for calculation
        z = v[2] * 100 # convert to cm for calculation

        truss.add_node(name, x,y,z)

    # define support
    supports = data["supports"]
    for id, support in supports.items():
        name = "node_" + str(id)
        truss.def_support(name, support[0], support[1], support[2], support[3], support[4], support[5])

    # create members
    members = data["members"]
    for id, member in members.items():
        name = "member_" + str(id)
        vertex_0_id = member["vertex_0_id"]
        vertex_1_id = member["vertex_1_id"]

        # like suggested here by Gorgious and CodeManX:
        # https://blender.stackexchange.com/questions/6155/how-to-convert-coordinates-from-vertex-to-world-space
        v_0 = mat @ vertices[vertex_0_id].co
        v_1 = mat @ vertices[vertex_1_id].co

        # save initial_positions to mix with deflection
        initial_positions = []
        for i in range(11):
            position = (v_0*(i) + v_1*(10-i))*0.1
            x = position[0]
            y = position[1]
            z = position[2]
            initial_positions.append([x,y,z])
        member["initial_positions"][str(frame)] = initial_positions

        node_0 = str("node_") + str(vertex_0_id)
        node_1 = str("node_") + str(vertex_1_id)

        truss.add_member(name, node_0, node_1, member["E"], member["G"], member["Iy"][str(frame)], member["Iz"][str(frame)], member["J"][str(frame)], member["A"][str(frame)])

        # add self weight
        kg_A = member["kg_A"][str(frame)]
        kN = kg_A * -0.0000981

        # add self weight as distributed load
        truss.add_member_dist_load(name, "FZ", kN, kN)

        # calculate lenght of parts (maybe usefull later ...)
        length = (v_0 - v_1).length
        frame_length += length

        # calculate and add weight to overall weight of structure
        kg = length * kg_A
        frame_kg += kg

        # store in member
        member["kg"][str(frame)] = kg
        member["length"][str(frame)] = length

    # add loads
    loads_v = data["loads_v"]
    for id, load in loads_v.items():
        name = "node_" + str(id)
        truss.add_node_load(name, 'FX', load[0])
        truss.add_node_load(name, 'FY', load[1])
        truss.add_node_load(name, 'FZ', load[2])

    loads_e = data["loads_e"]
    for id, load in loads_e.items():
        name = "member_" + str(id)
        truss.add_member_dist_load(name, 'FX', load[0]*0.01, load[0]*0.01) # m to cm
        truss.add_member_dist_load(name, 'FY', load[1]*0.01, load[1]*0.01) # m to cm
        truss.add_member_dist_load(name, 'FZ', load[2]*0.01, load[2]*0.01) # m to cm

    loads_f = data["loads_f"]
    for id, load in loads_f.items():
        # int(id), otherwise crashing Speicherzugriffsfehler
        face = data["structure"].data.polygons[int(id)]
        org_normal = face.normal

        # apply matrix
        # like suggested here by Gorgious and CodeManX:
        # https://blender.stackexchange.com/questions/6155/how-to-convert-coordinates-from-vertex-to-world-space
        normal = mat @ org_normal

        edge_keys = face.edge_keys
        area = face.area

        load_normal = load[0]
        load_projected = load[1]
        load_area_z = load[2]

        # get projected area
        # based on answer from Nikos Athanasiou:
        # https://stackoverflow.com/questions/24467972/calculate-area-of-polygon-given-x-y-coordinates
        vertex_ids = face.vertices
        vertices_temp = []
        for vertex_id in vertex_ids:
            vertex = vertices[vertex_id]

            # like suggested here by Gorgious and CodeManX:
            # https://blender.stackexchange.com/questions/6155/how-to-convert-coordinates-from-vertex-to-world-space
            v = mat @ vertex.co

            vertices_temp.append(v)

        n = len(vertices_temp)
        a = 0.0
        for i in range(n):
            j = (i + 1) % n
            v_i = vertices_temp[i]
            v_j = vertices_temp[j]

            a += v_i[0] * v_j[1]
            a -= v_j[0] * v_i[1]

        area_projected = abs(a) / 2.0

        # get distances and perimeter
        distances = []
        for edge_key in edge_keys:
            vertex_0_id = edge_key[0]
            vertex_1_id = edge_key[1]

            # like suggested here by Gorgious and CodeManX:
            # https://blender.stackexchange.com/questions/6155/how-to-convert-coordinates-from-vertex-to-world-space
            vertex_0_co = mat @ vertices[vertex_0_id].co
            vertex_1_co = mat @ vertices[vertex_1_id].co

            dist_vector = vertex_0_co - vertex_1_co
            dist = dist_vector.length
            distances.append(dist)

        perimeter = sum(distances)

        # define loads for each edge
        edge_load_normal = []
        edge_load_projected = []
        edge_load_area_z = []

        ratio = 1 / len(edge_keys)
        for edge_id, dist in enumerate(distances):
            # load_normal
            area_load = load_normal * area
            edge_load = area_load * ratio / dist * 0.01 # m to cm
            edge_load_normal.append(edge_load)

            # load projected
            area_load = load_projected * area_projected
            edge_load = area_load * ratio / dist * 0.01 # m to cm
            edge_load_projected.append(edge_load)

            # load projected
            area_load = load_area_z * area
            edge_load = area_load * ratio / dist * 0.01 # m to cm
            edge_load_area_z.append(edge_load)

        # i is the id within the class (0, 1, 3 and maybe more)
        # edge_id is the id of the edge in the mesh -> the member
        for i, edge_key in enumerate(edge_keys):
            # get name <---------------------------------------- maybe better method?
            for edge in edges:
                if edge.vertices[0] in edge_key:
                    if edge.vertices[1] in edge_key:
                        name = "member_" + str(edge.index)

            # edge_load_normal <--------------------------------- to be tested / checked
            x = edge_load_normal[i] * normal[0]
            y = edge_load_normal[i] * normal[1]
            z = edge_load_normal[i] * normal[2]

            truss.add_member_dist_load(name, 'FX', x, x)
            truss.add_member_dist_load(name, 'FY', y, y)
            truss.add_member_dist_load(name, 'FZ', z, z)

            # edge_load_projected
            z = edge_load_projected[i]
            truss.add_member_dist_load(name, 'FZ', z, z)

            # edge_load_area_z
            z = edge_load_area_z[i]
            truss.add_member_dist_load(name, 'FZ', z, z)

    # store frame based data
    data["frames"][str(frame)]["volume"] = frame_volume
    data["frames"][str(frame)]["area"] = frame_area
    data["frames"][str(frame)]["length"] = frame_length
    data["frames"][str(frame)]["kg"] = frame_kg

    return truss

# run a single thread calculation
def run_st(truss, frame):
    # scipy_available to pass forward
    if bpy.context.scene["<Phaenotyp>"]["scipy_available"]:
        truss.analyze(check_statics=False, sparse=True)
    else:
        truss.analyze(check_statics=False, sparse=False)

    feas = {}
    feas[str(frame)] = truss

    text = "Single thread job for frame " + str(frame) + " done"
    print_data(text)

    return feas

# run multiprocessing calculation
def run_mp(trusses):
    # get pathes
    path_addons = os.path.dirname(__file__) # path to the folder of addons
    path_script = path_addons + "/mp.py"
    path_python = sys.executable # path to bundled python
    path_blend = bpy.data.filepath # path to stored blender file
    directory_blend = os.path.dirname(path_blend) # directory of blender file
    name_blend = bpy.path.basename(path_blend) # name of file

    # create dir if not available
    try:
        os.mkdir(os.path.join(directory_blend, "Phaenotyp-mp"))
    except:
        pass

    # pickle trusses and members to file
    path_export = directory_blend + "/Phaenotyp-mp/Phaenotyp-export_mp.p"
    export_file = open(path_export, 'wb')
    export_data = [trusses, bpy.context.scene["<Phaenotyp>"]["members"].to_dict()]
    pickle.dump(export_data, export_file)
    export_file.close()

    # scipy_available to pass forward
    if bpy.context.scene["<Phaenotyp>"]["scipy_available"]:
        scipy_available = "True" # as string
    else:
        scipy_available = "False" # as string


    # subprocess call to mp
    task = [path_python, path_script, directory_blend, scipy_available]

    # list to handle jobs
    jobs = []

    # data to handle progress
    c = bpy.context.scene.frame_start
    end = bpy.context.scene.frame_end

    # feedback from python like suggested from Markus Amalthea Magnuson and user3759376 here
    # https://stackoverflow.com/questions/4417546/constantly-print-subprocess-output-while-process-is-running
    p = Popen(task, stdout=PIPE, bufsize=1)
    lines_iterator = iter(p.stdout.readline, b"")
    results = []
    while p.poll() is None:
        for line in lines_iterator:
            nline = line.rstrip()
            print(nline.decode("utf8"), end = "\r\n",flush =True)
            frame = nline.decode("utf8")
            progress.http.c = [c, end]
            c = c+1

            # pickle file
            path_import = directory_blend + "/Phaenotyp-mp/" + frame + ".p"
            file = open(path_import, 'rb')
            calculated_members = pickle.load(file)
            file.close()

            # interweave data
            #job = Thread(target=interweave_results, args=(frame, calculated_members,))
            #jobs.append(job)
            #job.start()
            results.append([frame, calculated_members])

    interweave_results(results)
    #for job in jobs:
    #    job.join()
    print("done")

force_list = [
  "axial", "moment_y", "moment_z", "moment_h", "shear_y", "shear_z", "shear_h",
  "torque", "sigma", "Wy", "WJ", "long_stress", "tau_shear", "tau_torsion",
  "sum_tau", "sigmav", "sigma", "max_long_stress", "max_tau_shear", "max_tau_torsion",
  "max_sum_tau", "max_sigmav", "max_sigma", "acceptable_sigma_buckling", "lamda",
  "lever_arm", "max_lever_arm", "initial_positions", "deflection", "overstress",
  "utilization", "normal_energy", "moment_energy", "strain_energy"
  ]

#def interweave_results(frame, calculated_members):
def interweave_results(results):
    scene = bpy.context.scene
    data = scene["<Phaenotyp>"]
    members = scene["<Phaenotyp>"]["members"]

    end = bpy.context.scene.frame_end

    #members.update(calculated_members)
    for result in results:
        frame = result[0]
        calculated_members = result[1]
        for id, member in calculated_members.items():
            for force_type in force_list:
                members[id][force_type][frame] = member[force_type][frame]

    #scene["<Phaenotyp>"]["members"] = new
    print("interweave")
    # update progress
    #progress.http.i = [int(frame), end]

def simple_sectional():
    scene = bpy.context.scene
    phaenotyp = scene.phaenotyp
    data = scene["<Phaenotyp>"]
    members = data["members"]
    frame = bpy.context.scene.frame_current

    for id, member in members.items():
        if abs(member["max_long_stress"][str(frame)]/member["acceptable_sigma_buckling"][str(frame)]) > 1:
            member["Do"][str(frame)] = member["Do"][str(frame)] * 1.2
            member["Di"][str(frame)] = member["Di"][str(frame)] * 1.2

        else:
            member["Do"][str(frame)] = member["Do"][str(frame)] * 0.8
            member["Di"][str(frame)] = member["Di"][str(frame)] * 0.8

        # set miminum size of Do and Di to avoid division by zero
        Do_Di_ratio = member["Do"][str(frame)]/member["Di"][str(frame)]
        if member["Di"][str(frame)] < 0.1:
            member["Di"][str(frame)] = 0.1
            member["Do"][str(frame)] = member["Di"][str(frame)] * Do_Di_ratio

def utilization_sectional():
    scene = bpy.context.scene
    phaenotyp = scene.phaenotyp
    data = scene["<Phaenotyp>"]
    members = data["members"]
    frame = bpy.context.scene.frame_current

    for id, member in members.items():
        ang = member["utilization"][str(frame)]

        # bei Fachwerkstäben
        #faktor_d = sqrt(abs(ang))

        # bei Biegestäben
        faktor_d= (abs(ang))**(1/3)

        Do_Di_ratio = member["Do"][str(frame)]/member["Di"][str(frame)]
        member["Do"][str(frame)] = member["Do"][str(frame)] * faktor_d
        member["Di"][str(frame)] = member["Di"][str(frame)] * faktor_d

        # set miminum size of Do and Di to avoid division by zero
        Do_Di_ratio = member["Do"][str(frame)]/member["Di"][str(frame)]
        if member["Di"][str(frame)] < 0.1:
            member["Di"][str(frame)] = 0.1
            member["Do"][str(frame)] = member["Di"][str(frame)] * Do_Di_ratio

def complex_sectional():
    scene = bpy.context.scene
    phaenotyp = scene.phaenotyp
    data = scene["<Phaenotyp>"]
    members = data["members"]
    frame = bpy.context.scene.frame_current

    for id, member in members.items():
        #treshhold bei Prüfung!
        # without buckling (Zugstab)

        if abs(member["max_long_stress"][str(frame)]/member["acceptable_sigma_buckling"][str(frame)]) > 1:
            faktor_a = 1+(abs(member["max_long_stress"][str(frame)])/member["acceptable_sigma_buckling"][str(frame)]-1)*0.36

        else:
            faktor_a = 0.5 + 0.6*(tanh((abs(member["max_long_stress"][str(frame)])/member["acceptable_sigma_buckling"][str(frame)] -0.5)*2.4))

        # bei Fachwerkstäben
        #faktor_d = sqrt(abs(faktor_a))

        # bei Biegestäben
        faktor_d = (abs(faktor_a))**(1/3)

        member["Do"][str(frame)] = member["Do"][str(frame)]*faktor_d
        member["Di"][str(frame)] = member["Di"][str(frame)]*faktor_d

        # set miminum size of Do and Di to avoid division by zero
        Do_Di_ratio = member["Do"][str(frame)]/member["Di"][str(frame)]
        if member["Di"][str(frame)] < 0.1:
            member["Di"][str(frame)] = 0.1
            member["Do"][str(frame)] = member["Di"][str(frame)] * Do_Di_ratio

def decimate_topology():
    scene = bpy.context.scene
    phaenotyp = scene.phaenotyp
    data = scene["<Phaenotyp>"]
    members = data["members"]
    obj = data["structure"] # applied to structure
    frame = bpy.context.scene.frame_current

    bpy.context.view_layer.objects.active = obj

    # create vertex-group if not existing
    bpy.ops.object.mode_set(mode = 'OBJECT')
    decimate_group = obj.vertex_groups.get("<Phaenotyp>decimate")
    if not decimate_group:
        decimate_group = obj.vertex_groups.new(name="<Phaenotyp>decimate")

    # create factor-list
    weights = []
    for vertex in obj.data.vertices:
        weights.append([])

    # create factors for nodes from members
    for id, member in members.items():
        factor = abs(member["max_long_stress"][str(frame)]/member["acceptable_sigma_buckling"][str(frame)])
        # first node
        vertex_0_id = member["vertex_0_id"]
        weights[vertex_0_id].append(factor)

        # second node
        vertex_1_id = member["vertex_1_id"]
        weights[vertex_1_id].append(factor)

    # sum up forces of each node and get highest value
    sums = []
    highest_sum = 0
    for id, weights_per_node in enumerate(weights):
        sum = 0
        if len(weights_per_node) > 0:
            for weight in weights_per_node:
                sum = sum + weight
                if sum > highest_sum:
                    highest_sum = sum

        sums.append(sum)


    for id, sum in enumerate(sums):
        weight = 1 / highest_sum * sum
        decimate_group.add([id], weight, 'REPLACE')


    # delete modifiere if existing
    try:
        bpy.ops.object.modifier_remove(modifier="<Phaenotyp>decimate")
    except:
        pass

    # create decimate modifiere
    mod = obj.modifiers.new("<Phaenotyp>decimate", "DECIMATE")
    mod.ratio = 0.1
    mod.vertex_group = "<Phaenotyp>decimate"
