# coding-utf8
from multiprocessing import Manager, Value, cpu_count, Pool
from numpy import array, empty, append, poly1d, polyfit
from math import sqrt
from math import tanh

import sys
from time import time

# import python from parent directory like pointed out here:
# https://stackoverflow.com/questions/714063/importing-modules-from-parent-folder
import os
import sys
import inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)
from PyNite import FEModel3D

import pickle

class basics:
    @staticmethod
    def return_max_diff_to_zero(list):
        list_copy = list.copy()
        list_copy.sort()

        smallest_minus = list_copy[0]
        biggest_plus = list_copy[len(list_copy)-1]

        if abs(smallest_minus) > abs(biggest_plus):
            return smallest_minus
        else:
            return biggest_plus

class material:
    kn_lamda = [10,20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200,210,220,230,240,250]

    kn235 = [16.5,15.8,15.3,14.8,14.2,13.5,12.7,11.8,10.7,9.5,8.2,6.9,5.9,5.1,4.4,3.9,3.4,3.1,2.7,2.5,2.2,2,1.9,1.7,1.6]
    kn275 = [20.5,19.4,18.8,18.0,17.1,16.0,14.8,13.3,11.7,9.9,8.2,6.9,5.9,5.1,4.4,3.9,3.4,3.1,2.7,2.5,2.2,2,1.9,1.7,1.6]
    kn355 = [24.5,23.2,22.3,21.2,20.0,18.5,16.7,14.7,12.2,9.9,8.2,6.9,5.9,5.1,4.4,3.9,3.4,3.1,2.7,2.5,2.2,2,1.9,1.7,1.6]
    knalu = [10.0,9.6,9.3,9,8.6,8.2,7.7,7.2,6.5,5.8,5.0,4.2,3.6,3.1,2.7,2.4,2.1,1.9,1.6,1.5,1.3,1.2,1.2,1.0,1.0]
    knholz = [1.60,1.33,1.28,1.20,1.11,1,0.86,0.71,0.56,0.46,0.38,0.32,0.27,0.23,0.2,0.18,0.16,0.14,0.127,0.114,0.114,0.114,0.114,0.114,0.114]
    kncustom = [16.5,15.8,15.3,14.8,14.2,13.5,12.7,11.8,10.7,9.5,8.2,6.9,5.9,5.1,4.4,3.9,3.4,3.1,2.7,2.5,2.2,2,1.9,1.7,1.6]

    library = [
        # name, name in dropdown, E, G, d, acceptable_sigma, acceptable_shear, acceptable_torsion, acceptable_sigmav, knick_model
        # diese gelten nach ÖNORM B 4600 für den Erhöhungsfall und entsprechen 100 % beim Knicken (lamda<20)
        ["steel_S235", "steel S235", 21000, 8100, 7.85, 16.5, 9.5, 10.5, 23.5, kn235],
        ["steel_S275", "steel S275", 21000, 8100, 7.85, 20.5, 11, 12.5, 27.5, kn275],
        ["steel_S355", "steel S355", 21000, 8100, 7.85, 24.5, 13, 15, 35.5, kn355],
        ["alu_EN_AC_Al_CU4Ti", "alu EN-AC Al Cu4Ti", 8000, 3000, 2.70, 10, 7, 10.5, 22.0, knalu],
        ["wood", "wood", 1000, 55, 0.35, 1.6, 0.1, 0.1, 2, knholz],
        ["custom", "Custom", 21000, 8100, 7.85, 16.0, 9.5, 10.5, 23.5, kncustom]
        ]

def print_data(text):
    print("Phaenotyp |", text)

# get arguments
directory_blend = sys.argv[1]
path_import = directory_blend + "/Phaenotyp-export_mp.p"
scipy_available = sys.argv[2]

# start timer
start_time = time()

def import_trusses():
    # get trusses stored as dict with frame as key
    file = open(path_import, 'rb')
    imported_data = pickle.load(file)
    file.close()

    return imported_data

# run one single fea and save result into feas (multiprocessing manager dict)
def run_fea(scipy_available, feas, truss, members, frame):
    # the variables truss, and frame are passed to mp
    # this variables can not be returned with multiprocessing
    # instead of this a dict with multiprocessing.Manager is created
    # the dict feas stores one anlysis for each frame
    # the dict fea is created temporarily in run_fea and is wirrten to feas
    # analyze the model
    if scipy_available == "True":
        truss.analyze(check_statics=False, sparse=True)
    if scipy_available == "False":
        truss.analyze(check_statics=False, sparse=False)

    for name, truss_member in truss.Members.items():
        id = name[7:]
        member = members[id]
        L = truss_member.L() # Member length
        T = truss_member.T() # Member local transformation matrix

        axial = []
        for i in range(11): # get the forces at 11 positions and
            axial_pos = truss_member.axial(x=L/10*i)
            axial_pos = axial_pos * (-1) # Druckkraft gleich minus
            axial.append(axial_pos)
        member["axial"][str(frame)] = axial

        # buckling
        member["ir"][str(frame)] = sqrt(member["J"][str(frame)]/member["A"][str(frame)]) # für runde Querschnitte in  cm

        moment_y = []
        for i in range(11): # get the forces at 11 positions and
            moment_y_pos = truss_member.moment("My", x=L/10*i)
            moment_y.append(moment_y_pos)
        member["moment_y"][str(frame)] = moment_y

        moment_z = []
        for i in range(11): # get the forces at 11 positions and
            moment_z_pos = truss_member.moment("Mz", x=L/10*i)
            moment_z.append(moment_z_pos)
        member["moment_z"][str(frame)] = moment_z

        shear_y = []
        for i in range(11): # get the forces at 11 positions and
            shear_y_pos = truss_member.shear("Fy", x=L/10*i)
            shear_y.append(shear_y_pos)
        member["shear_y"][str(frame)] = shear_y

        shear_z = []
        for i in range(11): # get the forces at 11 positions and
            shear_z_pos = truss_member.shear("Fz", x=L/10*i)
            shear_z.append(shear_z_pos)
        member["shear_z"][str(frame)] = shear_z

        torque = []
        for i in range(11): # get the forces at 11 positions and
            torque_pos = truss_member.torque(x=L/10*i)
            torque.append(torque_pos)
        member["torque"][str(frame)] = torque

        # modulus from the moments of area
        #(Wy and Wz are the same within a pipe)
        member["Wy"][str(frame)] = member["Iy"][str(frame)]/(member["Do"][str(frame)]/2)

        # polar modulus of torsion
        member["WJ"][str(frame)] = member["J"][str(frame)]/(member["Do"][str(frame)]/2)

        # calculation of the longitudinal stresses
        long_stress = []
        for i in range(11): # get the stresses at 11 positions and
            moment_h = sqrt(moment_y[i]**2+moment_z[i]**2)
            if axial[i] > 0:
                s = axial[i]/member["A"][str(frame)] + moment_h/member["Wy"][str(frame)]
            else:
                s = axial[i]/member["A"][str(frame)] - moment_h/member["Wy"][str(frame)]
            long_stress.append(s)

        # get max stress of the beam
        # (can be positive or negative)
        member["long_stress"][str(frame)] = long_stress
        member["max_long_stress"][str(frame)] = basics.return_max_diff_to_zero(long_stress) #  -> is working as fitness

        # calculation of the shear stresses from shear force
        # (always positive)
        tau_shear = []
        shear_h = []
        for i in range(11): # get the stresses at 11 positions and
            # shear_h
            s_h = sqrt(shear_y[i]**2+shear_z[i]**2)
            shear_h.append(s_h)

            tau = 1.333 * s_h/member["A"][str(frame)] # for pipes
            tau_shear.append(tau)

        member["shear_h"][str(frame)] = shear_h

        # get max shear stress of shear force of the beam
        # shear stress is mostly small compared to longitudinal
        # in common architectural usage and only importand with short beam lenght
        member["tau_shear"][str(frame)] = tau_shear
        member["max_tau_shear"][str(frame)] = max(tau_shear)

        # Calculation of the torsion stresses
        # (always positiv)
        tau_torsion = []
        for i in range(11): # get the stresses at 11 positions and
            tau = abs(torque[i]/member["WJ"][str(frame)])
            tau_torsion.append(tau)

        # get max torsion stress of the beam
        member["tau_torsion"][str(frame)] = tau_torsion
        member["max_tau_torsion"][str(frame)] = max(tau_torsion)

        # torsion stress is mostly small compared to longitudinal
        # in common architectural usage

        # calculation of the shear stresses form shear force and torsion
        # (always positiv)
        sum_tau = []
        for i in range(11): # get the stresses at 11 positions and
            tau = tau_shear[0] + tau_torsion[0]
            sum_tau.append(tau)

        member["sum_tau"][str(frame)] = sum_tau
        member["max_sum_tau"][str(frame)] = max(sum_tau)

        # combine shear and torque
        sigmav = []
        for i in range(11): # get the stresses at 11 positions and
            sv = sqrt(long_stress[0]**2 + 3*sum_tau[0]**2)
            sigmav.append(sv)

        member["sigmav"][str(frame)] = sigmav
        member["max_sigmav"][str(frame)] = max(sigmav)
        # check out: http://www.bs-wiki.de/mediawiki/index.php?title=Festigkeitsberechnung

        member["sigma"][str(frame)] = member["long_stress"][str(frame)]
        member["max_sigma"][str(frame)] = member["max_long_stress"][str(frame)]

        # for the definition of the fitness criteria prepared
        # max longitudinal stress for steel St360 in kN/cm²
        # tensile strength: 36 kN/cm², yield point 23.5 kN/cm²
        member["overstress"][str(frame)] = False

        # for example ["steel_S235", "steel S235", 21000, 8100, 7.85, 16.0, 9.5, 10.5, 23.5, knick_model235],
        #if abs(member["max_sigma"][str(frame)]) > member["acceptable_sigma"]:
        #    member["overstress"][str(frame)] = True

        # check overstress and add 1.05 savety factor
        safety_factor = 1.05
        if abs(member["max_tau_shear"][str(frame)]) > safety_factor*member["acceptable_shear"]:
            member["overstress"][str(frame)] = True

        if abs(member["max_tau_torsion"][str(frame)]) > safety_factor*member["acceptable_torsion"]:
            member["overstress"][str(frame)] = True

        if abs(member["max_sigmav"][str(frame)]) > safety_factor*member["acceptable_sigmav"]:
            member["overstress"][str(frame)] = True

        # buckling
        if member["axial"][str(frame)][0] < 0: # nur für Druckstäbe, axial kann nicht flippen?
            member["lamda"][str(frame)] = L*0.5/member["ir"][str(frame)] # für eingespannte Stäbe ist die Knicklänge 0.5 der Stablänge L, Stablänge muss in cm sein !
            if member["lamda"][str(frame)] > 20: # für lamda < 20 (kurze Träger) gelten die default-Werte)
                kn = member["knick_model"]
                function_to_run = poly1d(polyfit(material.kn_lamda, kn, 6))
                member["acceptable_sigma_buckling"][str(frame)] = function_to_run(member["lamda"][str(frame)])
                if member["lamda"][str(frame)] > 250: # Schlankheit zu schlank
                    member["overstress"][str(frame)] = True
                if safety_factor*abs(member["acceptable_sigma_buckling"][str(frame)]) > abs(member["max_sigma"][str(frame)]): # Sigma
                    member["overstress"][str(frame)] = True

            else:
                member["acceptable_sigma_buckling"][str(frame)] = member["acceptable_sigma"]

        # without buckling
        else:
            member["acceptable_sigma_buckling"][str(frame)] = member["acceptable_sigma"]
            member["lamda"][str(frame)] = None # to avoid missing KeyError


        if abs(member["max_sigma"][str(frame)]) > safety_factor*member["acceptable_sigma"]:
            member["overstress"][str(frame)] = True

        # lever_arm
        lever_arm = []
        moment_h = []
        for i in range(11):
            # moment_h
            m_h = sqrt(moment_y[i]**2+moment_z[i]**2)
            moment_h.append(m_h)

            # to avoid division by zero
            if member["axial"][str(frame)][i] < 0.1:
                lv = m_h / 0.1
            else:
                lv = m_h / member["axial"][str(frame)][i]

            lv = abs(lv) # absolute highest value within member
            lever_arm.append(lv)

        member["moment_h"][str(frame)] = moment_h
        member["lever_arm"][str(frame)] = lever_arm
        member["max_lever_arm"][str(frame)] = max(lever_arm)

        # Ausnutzungsgrad
        member["utilization"][str(frame)] = abs(member["max_long_stress"][str(frame)] / member["acceptable_sigma_buckling"][str(frame)])

        # Einführung in die Technische Mechanik - Festigkeitslehre, H.Balke, Springer 2010
        # Berechnung der strain_energy für Normalkraft

        normalkraft_energie=[]
        for i in range(10): # get the energie at 10 positions for 10 section
            ne = (axial[i]**2)*(L/10)/(2*member["E"]*member["A"][str(frame)])
            normalkraft_energie.append(ne)
        member["normal_energy"][str(frame)] = normalkraft_energie

        # Berechnung der strain_energy für Moment
        moment_energie=[]
        for i in range(10): # get the energie at 10 positions for 10 section
            moment_hq = moment_y[i]**2+moment_z[i]**2
            me = (moment_hq * L/10) / (member["E"] * member["Wy"][str(frame)] * member["Do"][str(frame)])
            moment_energie.append(me)
        member["moment_energy"][str(frame)] = moment_energie

        # Summe von Normalkraft und Moment-Verzerrunsenergie
        strain_energy = []
        for i in range(10):
            value = normalkraft_energie[i] + moment_energie[i]
            strain_energy.append(value)
        member["strain_energy"][str(frame)] = strain_energy

        # deflection
        deflection = []

        # --> taken from pyNite VisDeformedMember: https://github.com/JWock82/PyNite
        scale_factor = 10.0

        cos_x = array([T[0,0:3]]) # Direction cosines of local x-axis
        cos_y = array([T[1,0:3]]) # Direction cosines of local y-axis
        cos_z = array([T[2,0:3]]) # Direction cosines of local z-axis

        DY_plot = empty((0, 3))
        for i in range(11):
            # Calculate the local y-direction displacement
            dy_tot = truss_member.deflection('dy', L/10*i)

            # Calculate the scaled displacement in global coordinates
            DY_plot = append(DY_plot, dy_tot*cos_y*scale_factor, axis=0)

        # Calculate the local z-axis displacements at 20 points along the member's length
        DZ_plot = empty((0, 3))
        for i in range(11):
            # Calculate the local z-direction displacement
            dz_tot = truss_member.deflection('dz', L/10*i)

            # Calculate the scaled displacement in global coordinates
            DZ_plot = append(DZ_plot, dz_tot*cos_z*scale_factor, axis=0)

        # Calculate the local x-axis displacements at 20 points along the member's length
        DX_plot = empty((0, 3))

        Xi = truss_member.i_node.X
        Yi = truss_member.i_node.Y
        Zi = truss_member.i_node.Z

        for i in range(11):
            # Displacements in local coordinates
            dx_tot = [[Xi, Yi, Zi]] + (L/10*i + truss_member.deflection('dx', L/10*i)*scale_factor)*cos_x

            # Magnified displacements in global coordinates
            DX_plot = append(DX_plot, dx_tot, axis=0)

        # Sum the component displacements to obtain overall displacement
        D_plot = DY_plot + DZ_plot + DX_plot

        # <-- taken from pyNite VisDeformedMember: https://github.com/JWock82/PyNite

        # add to results
        for i in range(11):
            x = D_plot[i, 0] * 0.01
            y = D_plot[i, 1] * 0.01
            z = D_plot[i, 2] * 0.01

            deflection.append([x,y,z])

        member["deflection"][str(frame)] = deflection

    feas[str(frame)] = members

    text = "multiprocessing job for frame " + str(frame) + " done"
    print_data(text)
    sys.stdout.flush()

def mp_pool(imported_data):
    global scipy_available

    manager = Manager() # needed for mp
    feas = manager.dict() # is saving all calculations by frame

    cores = cpu_count()
    '''
    text = "rendering with " + str(cores) + " cores."
    print_data(text)
    '''

    pool = Pool(processes=cores)
    trusses, members = imported_data
    for frame, truss in trusses.items():
        pool.apply_async(run_fea, args=(scipy_available, feas, truss, members, frame,))

    pool.close()
    pool.join()

    return feas

def export_members(to_export):
    # export back to blender
    path_export = directory_blend + "/Phaenotyp-return_mp.p"
    file = open(path_export, 'wb')
    pickle.dump(dict(to_export), file) # use dict() to convert mp_dict to dict
    file.close()

if __name__ == "__main__":
    imported_data = import_trusses()
    to_export = mp_pool(imported_data)
    export_members(to_export)
    # give feedback to user
    end_time = time()

    # print only frames to make progress.http work correctly
    '''
    elapsed_time = end_time - start_time
    text = "time elapsed: " + str(elapsed_time) + " s"
    print_data(text)
    '''

    # exit
    sys.exit()
