# Releasenotes

## Version 0.4.2 – Unreleased

This update focuses on calculation reliability, material support and deformation
visualization. It includes the changes since version 0.4.1 and the current
Testing build, reviewed on 26 November 2026.

### Bug fixes

- Fixed torsion constants for solid and hollow rectangular profiles
  ([#4](https://github.com/bewegende-Architektur/Phaenotyp/issues/4)). Solid
  rectangles use the rectangle approximation; hollow rectangles use the thin-wall
  formula with wall thickness and centreline dimensions. `J` is recalculated
  from each member's current dimensions for every analysis frame and passed to
  PyNite. The solid-rectangle stress calculation based on `Wt` is unchanged.
- Fixed subprocess calculations that could fail without usable results
  ([#5](https://github.com/bewegende-Architektur/Phaenotyp/issues/5)). Unsaved
  files are detected before calculation, and the `use_scipy` setting is respected.
  If SciPy is requested but unavailable in the worker, calculation falls back
  to the dense NumPy solver and reports this in the console.
- Worker exceptions, file preparation and process launch failures, and missing,
  corrupt or incomplete results stop the job queue and show a message in Blender.
  Old results are cleared before calculation. A warning on stderr alone no
  longer discards a successful calculation with complete results.
- Fixed the job timer raising `IndexError: pop from empty list` after a failed
  calculation clears the queue; the timer is also removed when jobs finish.
- Fixed `wm.set_member` failing when called from a script before the panel is
  drawn. The panel and operator now share section and material initialization.
- Fixed custom member materials using steel defaults in PyNite. Members now use
  their actual E, G and density values, with separate material entries for
  different custom properties. Library material densities are also passed on.
- Fixed quad result handling with current NumPy and Blender 5.2: result arrays
  are read as scalar values, quad lengths are stored as Python numbers, and
  multiprocessing frame IDs are consistently handled as text.
- Corrected quad displacements from centimetres to Blender metres, removing an
  unintended factor of ten.

- Calculation error and unsaved-file messages are now in English. When the
  solver reports a singular stiffness matrix, the popup points to structural
  instability and asks users to check supports, connections and moment releases.

### Small improvements

- Changed the buckling-curve label to English.
- Removed the experimental additional material presets and their estimated
  buckling curves from members and quads. The original material library remains.

- Lowered the minimum custom E and G values to 100 kN/cm² and the minimum
  equivalent stress limit to 0.01 kN/cm² to support custom materials with lower stiffness.
- Added `Scale deformation` for members and quads, with the existing visual
  magnification of 10 as the default. New results store displacements without
  magnification; display scaling can be changed afterwards. Older results with
  stored or implicit magnification are taken into account.
- `Deflected / original` can now reach exactly 0%. Use deformation factor 1 and
  blend 0% for an unmagnified view. The tooltip explains both controls.
- Adjusted member deformation curves along their full length to meet displaced
  nodes. Inactive tension-only or compression-only members are displayed as
  straight connections between their displaced end nodes.

### Bayesian modelling (lab only)

- Updated the dependency installer to preserve Blender's bundled NumPy version,
  install binary wheels into the user environment and use
  `bayesian-optimization` version 2.0.4. Installation errors are propagated and
  temporary dependency constraints are removed afterwards.
- The installer no longer upgrades pip automatically. Bayesian modelling remains
  experimental and requires external libraries.

### More

- Updated the bundled solver to PyNiteFEA 3.2.0, including its MIT licence and
  provenance documentation in [Pynite/VENDORED.md](Pynite/VENDORED.md).
  The earlier local P-Delta partitioning and dense-matrix fixes are superseded
  by the updated upstream implementation.
- Kept dense NumPy analysis available without SciPy. Optional plotting and table
  libraries are loaded only when their output methods are used. New upstream
  features are not automatically exposed as Phaenotyp controls.
- Updated add-on metadata, the Blender manifest and the internal version to
  0.4.2. Refreshed `Testing/phaenotyp.zip` as a legacy add-on package;
  the Blender manifest is kept in the repository and excluded from this ZIP.
- Replaced earlier acrylic and deformation test files and removed unit tests
  with the current issue regressions and the 64-quad Blender regression.
  The earlier `MATERIAL_SOURCES.md` and `Testing/DEFORMATION.md` documents were
  removed.

### Testing and known limitations

- Regression tests cover rectangular profiles in both orientations, different
  wall thicknesses, and changed dimensions on existing members in the same and
  subsequent frames. Blender tests verify the `J` received by PyNite,
  analytical twist, the unchanged `Wt` stress calculation, scripted member
  creation and result integration.
- Subprocess tests cover all three PyNite calculation modes without SciPy,
  the dense fallback, warnings, worker failures, and missing, corrupt or
  incomplete results. The ten current automated tests and the 64-quad
  regression passed. The rectangular-profile Blender regression also passed
  from the extracted Testing ZIP, using Blender 5.2.3 on Linux.
- The member-curve adjustment is applied to stored deformation geometry; it does
  not change calculated forces or nodal displacements. The cause and physical
  accuracy of a P-Delta curve discrepancy remain unresolved. This is not a
  confirmed solver correction.
- Windows behaviour and visible GUI error messages still need manual review.
  Historical tests documented in `Pynite/VENDORED.md` describe their original
  environment and do not establish compatibility with every upstream feature.
- Restart Blender after updating and recalculate models. Existing multiprocessing
  pickle files should be regenerated after the solver update.

Thank you to [@mrgoodcat](https://github.com/mrgoodcat) for the detailed bug
reports and helpful suggestions in issues #4 and #5!
